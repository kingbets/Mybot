from telethon import TelegramClient, events
import json, os

api_id = YOUR_API_ID
api_hash = 'YOUR_API_HASH'

if not os.path.exists("members_db.json"):
    with open("members_db.json", "w") as f:
        json.dump({"group_users": {}, "private_users": {"users": []}}, f)

with open("members_db.json", "r") as f:
    members = json.load(f)

sessions = [f for f in os.listdir("sessions") if f.endswith(".session")]

clients = []

for session in sessions:
    client = TelegramClient(f"sessions/{session}", api_id, api_hash)
    clients.append(client)

    @client.on(events.NewMessage(chats=None))
    async def handler(event):
        chat = await event.get_chat()
        sender = await event.get_sender()
        user_id = str(sender.id)

        if event.is_channel:
            return
        if event.is_group or event.is_supergroup:
            group_id = str(chat.id)
            members["group_users"].setdefault(group_id, [])
            if user_id not in members["group_users"][group_id]:
                members["group_users"][group_id].append(user_id)
        elif event.is_private:
            if user_id not in members["private_users"]["users"]:
                members["private_users"]["users"].append(user_id)

        with open("members_db.json", "w") as f:
            json.dump(members, f)

for client in clients:
    client.start()

print("Watcher is running on all sessions...")
for client in clients:
    client.run_until_disconnected()