from telethon.sync import TelegramClient
from telethon.tl.functions.channels import InviteToChannelRequest
import json, os, time

api_id = YOUR_API_ID
api_hash = 'YOUR_API_HASH'
channel = 'your_channel_username'
delay = 10

with open("members_db.json", "r") as f:
    members = json.load(f)

users = list(set(
    user for group in members["group_users"].values() for user in group
))

sessions = [f for f in os.listdir("sessions") if f.endswith(".session")]
per_bot = len(users) // len(sessions) + 1

for index, session in enumerate(sessions):
    client = TelegramClient(f"sessions/{session}", api_id, api_hash)
    client.start()
    part = users[index * per_bot:(index + 1) * per_bot]
    for user_id in part:
        try:
            client(InviteToChannelRequest(channel, [int(user_id)]))
            print(f"{session} added {user_id}")
            with open("logs/added.txt", "a") as log:
                log.write(user_id + "\n")
        except Exception as e:
            print(f"{session} failed to add {user_id}: {e}")
            with open("logs/failed.txt", "a") as log:
                log.write(user_id + "\n")
        time.sleep(delay)
    client.disconnect()